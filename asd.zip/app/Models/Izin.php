<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Izin extends Model
{
    public $casts = [
        "id"=>"string"
    ];

    public function absen()
    { 
        return $this->belongsTo(Absen::class, "absen_id","id");
    }

    public function user()
    {
        return $this->belongsTo(User::class, "user_id", "id");
    }
}
