<?php

namespace App\Filament\Resources\SettingJamResource\Pages;

use App\Filament\Resources\SettingJamResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSettingJam extends CreateRecord
{
    protected static string $resource = SettingJamResource::class;
}
