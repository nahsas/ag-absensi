<?php

namespace App\Filament\Resources\DinasLuarResource\Pages;

use App\Filament\Resources\DinasLuarResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDinasLuar extends CreateRecord
{
    protected static string $resource = DinasLuarResource::class;
}
