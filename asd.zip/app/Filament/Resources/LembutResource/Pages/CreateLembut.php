<?php

namespace App\Filament\Resources\LembutResource\Pages;

use App\Filament\Resources\LembutResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLembut extends CreateRecord
{
    protected static string $resource = LembutResource::class;
}
